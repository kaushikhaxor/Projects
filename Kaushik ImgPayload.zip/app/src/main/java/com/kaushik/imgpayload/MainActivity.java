package com.kaushik.imgpayload;
 
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.*;

public class MainActivity extends Activity {

    private static final int SELECT_SO_CODE = 1;
    private static final int SELECT_PNG_CODE = 2;

    private Button selectLibButton, selectPngButton, injectButton;
    private ProgressBar progressBar;

    private String libPath = null;
    private String pngPath = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selectLibButton = (Button) findViewById(R.id.select_lib_button);
        selectPngButton = (Button) findViewById(R.id.select_png_button);
        injectButton = (Button) findViewById(R.id.inject_button);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);

        selectLibButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent libIntent = new Intent(Intent.ACTION_GET_CONTENT);
					libIntent.setType("*/*");
					startActivityForResult(libIntent, SELECT_SO_CODE);
				}
			});

        selectPngButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent pngIntent = new Intent(Intent.ACTION_GET_CONTENT);
					pngIntent.setType("image/png");
					startActivityForResult(pngIntent, SELECT_PNG_CODE);
				}
			});

        injectButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (libPath != null && pngPath != null) {
						injectPayload(pngPath, libPath);
					}
				}
			});
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            String path = getRealPathFromURI(uri);
            if (requestCode == SELECT_SO_CODE) {
                libPath = path;
                Toast.makeText(this, ".so Library selected", Toast.LENGTH_SHORT).show();
            } else if (requestCode == SELECT_PNG_CODE) {
                pngPath = path;
                Toast.makeText(this, "PNG selected", Toast.LENGTH_SHORT).show();
            }

            if (libPath != null && pngPath != null) {
                injectButton.setEnabled(true);
            }
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            String filePath = cursor.getString(column_index);
            cursor.close();
            return filePath;
        }
        return null;
    }

    private void injectPayload(String pngPath, String soPath) {
        progressBar.setVisibility(View.VISIBLE);
        String outputPath = "/sdcard/Download/Kaushik_payload.png";

        try {
            FileInputStream fisPng = new FileInputStream(pngPath);
            FileInputStream fisSo = new FileInputStream(soPath);
            FileOutputStream fos = new FileOutputStream(outputPath);

            byte[] buffer = new byte[1024];
            int length;

            // Copy PNG first
            while ((length = fisPng.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }

            // Add .so content at end

			while ((length = fisSo.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }

            fisPng.close();
            fisSo.close();
            fos.close();

            Toast.makeText(this, "Payload injected successfully!", Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        progressBar.setVisibility(View.GONE);
    }
}
